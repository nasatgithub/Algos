import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import java.sql.Connection;
import java.sql.DriverManager;


/**
 * Created by NasirAhmed on 16-Sep-16.
 */
public class MyDataSource {
    public Connection connection;
    public MyDataSource(String username, String password, String dbname) throws Exception {
        String driver = "com.mysql.jdbc.Driver";
        String connectionString = "jdbc:mysql://localhost:3306/"+dbname+"?useSSL=false";
        Class.forName(driver);
        connection = DriverManager.getConnection(connectionString, username, password);
    }

    public Connection getConnection() {
        return connection;
    }

}
