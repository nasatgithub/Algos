import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by NasirAhmed on 17-Sep-16.
 */
public class Employee {
    private int employeeId;
    private Position servesAs;
    private Person person;
    private String address;
    private String email;
    private List<Dependents> dependentsList;
    private List<Benefit> selectedBenefitList;

    public Employee(int employeeId, Connection connection) throws SQLException {
        this.employeeId = employeeId;
        int servesAsId = 0;

        String employeeQuery = "select * from employee where id=?";
        PreparedStatement fetchEmployee = connection.prepareStatement(employeeQuery);
        fetchEmployee.setInt(1, employeeId);
        ResultSet rs = fetchEmployee.executeQuery();
        while(rs.next()){
            servesAsId = rs.getInt(2);
            this.address = rs.getString(3);
            this.email = rs.getString(4);
        }

        String positionQuery = "select * from position where id=?";
        PreparedStatement fetchPosition = connection.prepareStatement(positionQuery);
        fetchPosition.setInt(1, servesAsId);
        rs = fetchPosition.executeQuery();
        while(rs.next()){
            Position pos = new Position(rs.getInt(1), rs.getString(2));
            this.servesAs = pos;
        }

        String personQuery = "select * from person where id=?";
        PreparedStatement fetchPerson = connection.prepareStatement(personQuery);
        fetchPerson.setInt(1, employeeId);
        rs = fetchPerson.executeQuery();
        while(rs.next()){
            Person person = new Person(rs.getInt(1), rs.getString(2));
            this.person = person;
        }

        // TODO
        // construct dependentsList and selectedBenefitsList





    }

    public static void main(String args[]) throws Exception {
       MyDataSource myds = new MyDataSource("root","mydbServer1234","dbta_assignment4");
       Connection connection = myds.getConnection();
       Employee employee = new Employee(1, connection);

    }

}

class Person {
    private int id;
    private String name;

    public Person(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}

class Dependents {
    private Person person;
    private FamilyRelationship relatedBy;

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public FamilyRelationship getRelatedBy() {
        return relatedBy;
    }

    public void setRelatedBy(FamilyRelationship relatedBy) {
        this.relatedBy = relatedBy;
    }
}

class Position {
    private int id;
    private String title;

    public Position(int id, String title) {
      this.id = id;
      this.title = title;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}

class Benefit {
    private int id;
    private String type;
    private List<Employee> employeeList;
    private List<BenefitPlan> benefitPlanList;

}

class BenefitPlan {
    private int id;
    private String name;
    private String description;
    private List<Position> allowedForPositions;
    private List<PayPeriod> duringList;

}

class PayPeriod {
    private int id;
    private String duration;
}

class Cost {
    private BenefitPlan benefitPlan;
    private PayPeriod payPeriod;
    private double employee;
    private double employer;
}


enum FamilyRelationship {
    Spouse,
    Child,
    Parent,
    Sibling,
    Other
}
